<?php
echo shell_exec('sudo python /var/www/ultrasonic.py');
?>
